'''Weapon settings'''
unlimited_ammo = False
current_weapon = None
next_gun = None
prev_gun = None
gun_list = []
